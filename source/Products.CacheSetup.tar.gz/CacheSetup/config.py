from zLOG import LOG, INFO, BLATHER
# BBB: CMF < 1.5
try:
    from Products.CMFCore.permissions import AddPortalContent
except ImportError:
    from Products.CMFCore.CMFCorePermissions import AddPortalContent

GLOBALS = globals()

ADD_CONTENT_PERMISSION = AddPortalContent
PROJECT_NAME = 'CacheSetup'
SKINS_DIR = 'skins'
CACHE_TOOL_ID = 'portal_cache_settings'
PAGE_CACHE_MANAGER_ID = 'CacheSetup_PageCache'
OFS_CACHE_ID = 'CacheSetup_OFSCache'
RR_CACHE_ID = 'CacheSetup_ResourceRegistryCache'

ENABLE_MACRO_CACHE = False
MACRO_CACHE_SIZE = 500  # maximum number of cached objects
MACRO_CACHE_AGE = 3600  # maximum age of a cached object in seconds

def log(msg, level=BLATHER):
    LOG(PROJECT_NAME, level, msg)


