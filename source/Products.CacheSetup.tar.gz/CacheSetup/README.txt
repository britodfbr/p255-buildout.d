NOTE: If you have a pre-beta CacheFu installation, you must uninstall it 
BEFORE putting the new CacheFu products in your Products directory.

The docs are out of date but we are working on it.

See "audiences.rest" in the /docs directory.
