from Interface import Interface

class ICacheRule(Interface):
    """ marker interface for cache rules """

class ICacheToolFolder(Interface):
    """ marker interface for cache tool folders """
