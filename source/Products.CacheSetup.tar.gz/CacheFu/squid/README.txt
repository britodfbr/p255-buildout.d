export PYTHONPATH=$PYTHONPATH:/opt/Zope-2.8/lib/python
python makeconfig.py

makeconfig generates a set of squid configuration files for CacheFu
based on values in a config file (specified with the -c option;
defaults to squid.cfg).  The files are built from a set of templates
(in the directory specified with the -t option; defaults to
./templates) and written to the directory specified with the -o option
(defaults to ./etc).  Once you have generated the files, you can
deploy them by running the "deploy" script in your output directory.

You will need to set the values in squid.cfg (or your own .cfg file)
to appropriate ones for your system.  We are also working on a
skeletor plug-in.
